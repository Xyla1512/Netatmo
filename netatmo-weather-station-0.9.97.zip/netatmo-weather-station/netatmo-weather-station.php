<?php
/**
 * Plugin Name: Netatmo Weather Station Pro
 * Plugin URI: https://frankneumann.de/netatmo-weather-station
 * Description: Reads and stores all data from your Netatmo weather station with full Elementor integration, animated charts and professional dashboard.
 * Version: 0.9.97
 * Author: Frank Neumann
 * Author URI: https://frankneumann.de
 * License: GPL v2 or later
 * Text Domain: netatmo-weather-station
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'NAWS_VERSION',        '0.9.97' );
define( 'NAWS_PLUGIN_FILE',    __FILE__ );
define( 'NAWS_PLUGIN_DIR',     plugin_dir_path( __FILE__ ) );
define( 'NAWS_PLUGIN_URL',     plugin_dir_url( __FILE__ ) );
define( 'NAWS_PLUGIN_BASENAME',plugin_basename( __FILE__ ) );
define( 'NAWS_DB_VERSION',     '1.4' );
define( 'NAWS_TABLE_READINGS', 'naws_readings' );
define( 'NAWS_TABLE_MODULES',  'naws_modules' );
define( 'NAWS_TABLE_DAILY',    'naws_daily_summary' );

// ── Safe require helper ────────────────────────────────────────────────────
function naws_require( $file ) {
    if ( file_exists( $file ) ) {
        require_once $file;
    } else {
        // Log missing file, don't crash
        error_log( 'NAWS: Missing file ' . $file );
    }
}

// ── Core classes (always needed) ──────────────────────────────────────────
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-lang.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-crypto.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-helpers.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-database.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-api.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-importer-v2.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-cron.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-astro.php' );
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-forecast.php' );

// ── Admin classes (only in admin context) ─────────────────────────────────
if ( is_admin() ) {
    naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-admin.php' );
}

// ── Frontend / shortcode classes ──────────────────────────────────────────
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-shortcodes.php' );

// ── AJAX (admin-ajax.php runs in admin context but serves frontend too) ───
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-ajax.php' );

// ── REST API (always loaded – routes registered on rest_api_init) ─────────
naws_require( NAWS_PLUGIN_DIR . 'includes/class-naws-rest-api.php' );


/**
 * Main plugin bootstrap
 */
final class Netatmo_Weather_Station {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook( NAWS_PLUGIN_FILE,   [ 'NAWS_Database', 'install' ] );
        register_deactivation_hook( NAWS_PLUGIN_FILE, [ 'NAWS_Cron', 'deactivate' ] );

        add_action( 'plugins_loaded', [ $this, 'init' ] );
        add_action( 'init',           [ $this, 'load_textdomain' ] );
    }

    public function init() {
        // Always boot cron and shortcodes
        NAWS_Cron::instance();
        NAWS_Shortcodes::instance();
        NAWS_Ajax::instance();
        NAWS_Rest_API::init();

        // ── Cron watchdog: schedule if missing OR stale ─────────────────────
        $next_fetch = wp_next_scheduled( NAWS_Cron::HOOK_FETCH );
        $next_daily = wp_next_scheduled( NAWS_Cron::HOOK_DAILY );

        if ( ! $next_fetch || ! $next_daily ) {
            // Event completely missing – schedule fresh
            NAWS_Cron::schedule();
        } elseif ( $next_fetch > 0 ) {
            // Self-healing: if the fetch event is stuck more than 2× interval
            // in the past, WordPress-Cron never picked it up. Clear & reschedule.
            $opts     = get_option( 'naws_settings', [] );
            $interval = max( 5, intval( $opts['cron_interval'] ?? 10 ) ) * MINUTE_IN_SECONDS;
            $overdue  = time() - $next_fetch;

            if ( $overdue > $interval * 2 ) {
                wp_clear_scheduled_hook( NAWS_Cron::HOOK_FETCH );
                NAWS_Cron::schedule();
            }
        }

        // Admin only
        if ( is_admin() ) {
            NAWS_Admin::instance();

            // ── Encrypt existing plaintext secrets (one-time migration) ───────
            if ( get_option( 'naws_crypto_migrated' ) !== NAWS_VERSION ) {
                NAWS_Crypto::migrate();
            }

            // ── One-time cleanup: remove stale timestamp readings from DB ─────
            // Before v0.9.93, date_min_temp / date_max_temp etc. were saved as
            // sensor readings (huge integers). Delete them once, then flag done.
            if ( ! get_option( 'naws_cleanup_timestamp_readings' ) ) {
                global $wpdb;
                $table = $wpdb->prefix . NAWS_TABLE_READINGS;
                $wpdb->query( "DELETE FROM {$table} WHERE parameter IN (
                    'time_utc','date_min_temp','date_max_temp',
                    'date_min_pressure','date_max_pressure',
                    'date_max_wind_str','date_max_gust'
                )" );
                update_option( 'naws_cleanup_timestamp_readings', true, false );
            }
        }

    }

    public function load_textdomain() {
        load_plugin_textdomain(
            'netatmo-weather-station',
            false,
            dirname( NAWS_PLUGIN_BASENAME ) . '/languages'
        );
    }
}

function naws() {
    return Netatmo_Weather_Station::instance();
}
naws();
