<?php
/* templates/gauge.php – [naws_gauge] animated gauge */
if ( ! defined( 'ABSPATH' ) ) exit;

$param    = $atts['parameter'];
$label    = ! empty( $atts['title'] ) ? $atts['title'] : NAWS_Helpers::get_label( $param );
$unit     = NAWS_Helpers::get_unit( $param );
$val_raw  = $value ?? 0;

// Sensible defaults per parameter
$defaults = [
    'Temperature'  => [ 'min' => -20, 'max' => 50  ],
    'Humidity'     => [ 'min' =>   0, 'max' => 100 ],
    'Pressure'     => [ 'min' => 960, 'max' => 1060 ],
    'CO2'          => [ 'min' => 350, 'max' => 2000 ],
    'Noise'        => [ 'min' =>  30, 'max' => 100 ],
    'WindStrength' => [ 'min' =>   0, 'max' => 100 ],
];
$def_min = $defaults[ $param ]['min'] ?? 0;
$def_max = $defaults[ $param ]['max'] ?? 100;
$g_min   = $atts['min'] !== '' ? floatval( $atts['min'] ) : $def_min;
$g_max   = $atts['max'] !== '' ? floatval( $atts['max'] ) : $def_max;

// Clamp value to 0-1 range for gauge.js
$fraction = $g_max > $g_min ? ( $val_raw - $g_min ) / ( $g_max - $g_min ) : 0;
$fraction = max( 0, min( 1, $fraction ) );
?>
<div class="naws-wrap naws-theme-light">
    <div class="naws-gauge-wrap" style="max-width:260px;margin:0 auto;text-align:center;">
        <canvas id="<?php echo esc_attr( $gauge_id ); ?>" style="width:100%;height:auto"></canvas>
        <div class="naws-gauge-label" style="font-size:.85rem;font-weight:700;color:#1e293b;margin-top:4px;">
            <?php echo esc_html( $label ); ?>
        </div>
        <div class="naws-gauge-value" style="font-size:1.4rem;font-weight:800;color:#2d8f7b;">
            <?php echo esc_html( $val_raw . ( $unit ? ' ' . $unit : '' ) ); ?>
        </div>
    </div>
    <script>
    (function(){
        var opts = {
            angle: -0.2, lineWidth: 0.2, radiusScale: 1,
            pointer: { length: 0.6, strokeWidth: 0.035, color: '#1e293b' },
            limitMax: false, limitMin: false,
            colorStart: '#2d8f7b', colorStop: '#2d8f7b',
            strokeColor: '#e2e8f0', generateGradient: true, highDpiSupport: true,
        };
        var target = document.getElementById(<?php echo wp_json_encode( $gauge_id ); ?>);
        if ( target && typeof Gauge !== 'undefined' ) {
            var gauge = new Gauge(target).setOptions(opts);
            gauge.maxValue = 1;
            gauge.setMinValue(0);
            gauge.animationSpeed = 32;
            gauge.set(<?php echo (float) $fraction; ?>);
        }
    }());
    </script>
</div>
