<?php
/* templates/chart.php */
if ( ! defined( 'ABSPATH' ) ) exit;

$period = $atts['period'] ?? '7d';
$show_picker = $atts['show_range_picker'] !== 'false';
$params = array_map('trim', explode(',', $atts['parameters'] ?? 'Temperature'));
?>
<div class="naws-wrap naws-theme-<?php echo esc_attr($atts['theme']); ?>">
    <div class="naws-chart-wrap">
        <div class="naws-chart-header">
            <?php if (!empty($atts['title'])) : ?>
                <h3 class="naws-chart-title"><?php echo esc_html($atts['title']); ?></h3>
            <?php endif; ?>
            <?php if ($show_picker && !($is_compare ?? false)) : ?>
            <div class="naws-range-picker">
                <button class="naws-range-btn <?php echo $period==='1d'?'active':''; ?>" data-period="1d">24h</button>
                <button class="naws-range-btn <?php echo $period==='7d'?'active':''; ?>" data-period="7d">7d</button>
                <button class="naws-range-btn <?php echo $period==='30d'?'active':''; ?>" data-period="30d">30d</button>
                <button class="naws-range-btn <?php echo $period==='90d'?'active':''; ?>" data-period="90d">90d</button>
                <button class="naws-range-btn <?php echo $period==='365d'?'active':''; ?>" data-period="365d">1J</button>
            </div>
            <?php elseif ($is_compare ?? false) : ?>
            <div class="naws-range-picker">
                <span style="font-size:0.75rem; color:var(--naws-text-muted); align-self:center;">
                    📅 <?php
                        $range_str = ! empty( $compare_years )
                            ? esc_html( min($compare_years) . ' – ' . max($compare_years) )
                            : 'Jahresvergleich';
                        echo $range_str;
                    ?>
                </span>
            </div>
            <?php endif; ?>
        </div>
        <div class="naws-chart-canvas-wrap">
            <div class="naws-chart-loading"><div class="naws-spinner"></div></div>
            <canvas id="<?php echo esc_attr($chart_id); ?>" height="<?php echo esc_attr($atts['height']); ?>"></canvas>
        </div>
    </div>
</div>

<script>
(function(){
    document.addEventListener('DOMContentLoaded', function() {
        <?php if ( $is_compare ?? false ) : ?>
        if (typeof window.NAWS_YearCompare !== 'undefined') {
            new window.NAWS_YearCompare({
                chartId:   '<?php echo esc_js($chart_id); ?>',
                moduleId:  '<?php echo esc_js($atts['module_id']); ?>',
                parameter: <?php echo json_encode($params[0] ?? 'Temperature'); ?>,
                years:     <?php echo json_encode(array_map('intval', $compare_years ?? [])); ?>,
                chartType: '<?php echo esc_js($atts['chart_type'] ?? 'line'); ?>',
                theme:     '<?php echo esc_js($atts['theme']); ?>'
            });
        }
        <?php else : ?>
        if (typeof window.NAWS_Chart !== 'undefined') {
            new window.NAWS_Chart({
                chartId:    '<?php echo esc_js($chart_id); ?>',
                moduleId:   '<?php echo esc_js($atts['module_id']); ?>',
                parameters: <?php echo json_encode($params); ?>,
                period:     '<?php echo esc_js($period); ?>',
                chartType:  '<?php echo esc_js($atts['chart_type'] ?? 'line'); ?>',
                theme:      '<?php echo esc_js($atts['theme']); ?>'
            });
        }
        <?php endif; ?>
    });
})();
</script>
<?php
