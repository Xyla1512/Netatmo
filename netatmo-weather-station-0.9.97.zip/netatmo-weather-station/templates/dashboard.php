<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php
/* ── Determine the "hero" values ─────────────────────────────
   Priority: outdoor module (NAModule1) > base (NAMain)      */
$hero = [
    'temp'     => null,
    'humidity' => null,
    'pressure' => null,
    'rain'     => null,
    'temp_lbl' => naws__( 'card_temperature' ),
];
$latest_ts = 0;

foreach ( $modules as $module ) {
    $mid      = $module['module_id'];
    $mtype    = $module['module_type'];
    $readings = $by_mod[$mid] ?? [];

    foreach ( $readings as $param => $data ) {
        $ts = intval( $data['time'] ?? 0 );
        if ( $ts > $latest_ts ) $latest_ts = $ts;

        if ( $param === 'Temperature' ) {
            if ( $mtype === 'NAModule1' || $hero['temp'] === null ) {
                $hero['temp']     = $data;
                $hero['temp_lbl'] = $mtype === 'NAModule1'
                    ? naws__( 'param_temp_out' )
                    : naws__( 'card_temperature' );
            }
        }
        if ( $param === 'Humidity'       && $hero['humidity'] === null ) $hero['humidity'] = $data;
        if ( in_array($param, ['Pressure','AbsolutePressure']) && $hero['pressure'] === null ) $hero['pressure'] = $data;
        if ( in_array($param, ['sum_rain_1','Rain'])           && $hero['rain']     === null ) $hero['rain']     = $data;
    }
}
?>

<div class="naws-wrap naws-theme-<?php echo esc_attr($atts['theme']); ?>">

    <?php /* ── Header ─────────────────────────────────────── */ ?>
    <div class="naws-header">
        <?php if ( ! empty( $atts['title'] ) ) : ?>
            <h2 class="naws-header-title"><?php echo esc_html($atts['title']); ?></h2>
        <?php endif; ?>
        <div class="naws-last-updated">
            <span class="naws-status-dot"></span>
            <?php
            echo $latest_ts
                ? esc_html( sprintf( 'Aktualisiert vor %s', human_time_diff($latest_ts) ) )
                : naws__( 'no_data' );
            ?>
        </div>
    </div>

    <?php /* ── Hero Strip ─────────────────────────────────── */ ?>
    <div class="naws-hero-strip">

        <?php if ( $hero['temp'] ) : ?>
        <div class="naws-hero-card naws-hero-temp">
            <div class="naws-hero-icon">🌡️</div>
            <div class="naws-hero-body">
                <div class="naws-hero-label"><?php echo esc_html($hero['temp_lbl']); ?></div>
                <div class="naws-hero-value">
                    <span class="naws-count-up" data-value="<?php echo esc_attr($hero['temp']['value']); ?>"><?php echo esc_html($hero['temp']['value']); ?></span>
                    <span class="naws-hero-unit"><?php echo esc_html($hero['temp']['unit']); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( $hero['humidity'] ) : ?>
        <div class="naws-hero-card naws-hero-humidity">
            <div class="naws-hero-icon">💧</div>
            <div class="naws-hero-body">
                <div class="naws-hero-label"><?php naws_e( 'param_humidity' ); ?></div>
                <div class="naws-hero-value">
                    <span class="naws-count-up" data-value="<?php echo esc_attr($hero['humidity']['value']); ?>"><?php echo esc_html($hero['humidity']['value']); ?></span>
                    <span class="naws-hero-unit"><?php echo esc_html($hero['humidity']['unit']); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( $hero['pressure'] ) : ?>
        <div class="naws-hero-card naws-hero-pressure">
            <div class="naws-hero-icon">🔵</div>
            <div class="naws-hero-body">
                <div class="naws-hero-label"><?php naws_e( 'card_pressure' ); ?></div>
                <div class="naws-hero-value">
                    <span class="naws-count-up" data-value="<?php echo esc_attr($hero['pressure']['value']); ?>"><?php echo esc_html($hero['pressure']['value']); ?></span>
                    <span class="naws-hero-unit"><?php echo esc_html($hero['pressure']['unit']); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( $hero['rain'] ) : ?>
        <div class="naws-hero-card naws-hero-rain">
            <div class="naws-hero-icon">🌧️</div>
            <div class="naws-hero-body">
                <div class="naws-hero-label"><?php naws_e( 'card_rain' ); ?></div>
                <div class="naws-hero-value">
                    <span class="naws-count-up" data-value="<?php echo esc_attr($hero['rain']['value']); ?>"><?php echo esc_html($hero['rain']['value']); ?></span>
                    <span class="naws-hero-unit"><?php echo esc_html($hero['rain']['unit']); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /.naws-hero-strip -->

    <?php /* ── Module Accordion ─────────────────────────────── */ ?>
    <div class="naws-accordion">

        <?php
        $mod_idx = 0;
        foreach ( $modules as $module ) :
            $mod_id   = $module['module_id'];
            $readings = $by_mod[$mod_id] ?? [];
            if ( empty($readings) ) continue;

            $icons = [
                'NAMain'    => '🏠',
                'NAModule1' => '🌿',
                'NAModule2' => '💨',
                'NAModule3' => '🌧️',
                'NAModule4' => '🛋️',
                'NHC'       => '❤️',
            ];
            $icon = $icons[$module['module_type']] ?? '📡';

            $bpct = null;
            if ( ! empty($module['battery_vp']) && $module['module_type'] !== 'NAMain' ) {
                $bpct = max(0, min(100, round(($module['battery_vp'] - 3500) / 2500 * 100)));
            }

            // Quick-peek: primary sensor value shown in collapsed header
            $peek_map = ['NAModule3'=>'sum_rain_1','NAMain'=>'Pressure','NAModule4'=>'Pressure'];
            $peek_param = $peek_map[$module['module_type']] ?? 'Temperature';
            $peek = $readings[$peek_param] ?? reset($readings);

            $open = ($mod_idx === 0);
            $mod_idx++;
        ?>
        <div class="naws-accordion-item<?php echo $open ? ' is-open' : ''; ?>">

            <button class="naws-accordion-header" type="button" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>">
                <span class="naws-accordion-icon"><?php echo esc_html($icon); ?></span>
                <span class="naws-accordion-name"><?php echo esc_html($module['module_name']); ?></span>
                <span class="naws-accordion-badge"><?php echo esc_html(NAWS_Helpers::module_type_label($module['module_type'])); ?></span>

                <span class="naws-accordion-meta">
                    <?php if ( $bpct !== null ) :
                        $bcol = $bpct < 20 ? '#ef4444' : ($bpct < 50 ? '#f59e0b' : '#10b981');
                    ?>
                    <span class="naws-battery-mini-wrap" title="Batterie <?php echo esc_attr($bpct); ?>%">
                        <span class="naws-battery-mini">
                            <span class="naws-battery-mini-fill" style="width:<?php echo esc_attr($bpct); ?>%;background:<?php echo esc_attr($bcol); ?>"></span>
                        </span>
                        <span class="naws-battery-mini-label"><?php echo esc_html($bpct); ?>%</span>
                    </span>
                    <?php endif; ?>

                    <?php if ( $peek ) : ?>
                    <span class="naws-accordion-peek">
                        <?php echo esc_html($peek['value']); ?><small>&thinsp;<?php echo esc_html($peek['unit']); ?></small>
                    </span>
                    <?php endif; ?>
                </span>

                <span class="naws-accordion-arrow" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </span>
            </button>

            <div class="naws-accordion-body">
                <div class="naws-sensor-grid">
                    <?php foreach ( $readings as $param => $data ) :
                        $is_co2  = ($param === 'CO2');
                        $is_wind = in_array($param, ['WindAngle','GustAngle']);
                        if ($is_co2) $co2_level = NAWS_Helpers::get_co2_level($data['raw']);
                    ?>
                    <div class="naws-sensor-card <?php echo esc_attr($data['css_class']); ?>">
                        <div class="naws-sensor-top">
                            <span class="naws-sensor-icon"><?php echo esc_html($data['icon']); ?></span>
                            <span class="naws-sensor-label"><?php echo esc_html($data['label']); ?></span>
                        </div>
                        <div class="naws-sensor-value">
                            <span class="naws-count-up" data-value="<?php echo esc_attr($data['value']); ?>"><?php echo esc_html($data['value']); ?></span>
                            <span class="naws-sensor-unit"><?php echo esc_html($data['unit']); ?></span>
                        </div>
                        <?php if ($is_co2) : ?>
                        <span class="naws-co2-indicator naws-co2-<?php echo esc_attr($co2_level['level']); ?>">
                            ● <?php echo esc_html($co2_level['label']); ?>
                        </span>
                        <?php endif; ?>
                        <?php if ($is_wind && !empty($readings['WindAngle']['raw'])) : ?>
                        <div class="naws-compass naws-compass-sm">
                            <div class="naws-compass-needle" data-angle="<?php echo esc_attr($readings['WindAngle']['raw']); ?>"></div>
                        </div>
                        <div class="naws-sensor-dir"><?php echo esc_html(NAWS_Helpers::degrees_to_compass(floatval($readings['WindAngle']['raw']))); ?></div>
                        <?php endif; ?>
                        <div class="naws-sensor-age"><?php echo esc_html(sprintf('vor %s', human_time_diff($data['time']))); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php
                $chart_params  = array_filter(array_keys($readings), fn($p) => !in_array($p, ['WindAngle','GustAngle']));
                $chart_params  = array_slice(array_values($chart_params), 0, 3);
                $dash_chart_id = 'naws-dash-chart-' . sanitize_html_class($mod_id);
                ?>
                <div class="naws-chart-wrap naws-module-chart">
                    <div class="naws-chart-header">
                        <h3 class="naws-chart-title"><?php echo 'Verlauf'; ?></h3>
                        <div class="naws-range-picker">
                            <button class="naws-range-btn" data-period="1d">24h</button>
                            <button class="naws-range-btn active" data-period="7d">7d</button>
                            <button class="naws-range-btn" data-period="30d">30d</button>
                        </div>
                    </div>
                    <div class="naws-chart-canvas-wrap">
                        <div class="naws-chart-loading"><div class="naws-spinner"></div></div>
                        <canvas id="<?php echo esc_attr($dash_chart_id); ?>" height="260"></canvas>
                    </div>
                </div>
                <script>
                (function() {
                    if (typeof window.NAWS_Chart !== 'undefined' && typeof Chart !== 'undefined') {
                        new window.NAWS_Chart({
                            chartId:    '<?php echo esc_js($dash_chart_id); ?>',
                            moduleId:   '<?php echo esc_js($mod_id); ?>',
                            parameters: <?php echo json_encode($chart_params); ?>,
                            period:     '7d',
                            chartType:  'line',
                            theme:      '<?php echo esc_js($atts['theme']); ?>'
                        });
                    }
                })();
                </script>
            </div><!-- /.naws-accordion-body -->
        </div><!-- /.naws-accordion-item -->
        <?php endforeach; ?>

    </div><!-- /.naws-accordion -->

</div><!-- /.naws-wrap -->
