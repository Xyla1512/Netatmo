<?php
/**
 * Template: [naws_history title=""]
 * v1.0.0 – Historical yearly charts: pressure, temp min/max/avg, rain
 * Per-year toggle legend, full-width, click-to-enlarge modal (1920px)
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$widget_id  = 'naws-hist-' . wp_unique_id();
$nonce      = wp_create_nonce('naws_public_nonce');
$ajax_url   = admin_url('admin-ajax.php');
$outdoor_id = '';
$indoor_id  = '';
foreach ( NAWS_Database::get_modules( true ) as $m ) {
    if ( $m['module_type'] === 'NAModule1' ) $outdoor_id = $m['module_id'];
    if ( $m['module_type'] === 'NAMain'    ) $indoor_id  = $m['module_id'];
}
$range = NAWS_Database::get_daily_data_range();
$year_from = $range ? (int) substr($range['date_begin'], 0, 4) : (int) date('Y');
$year_to   = $range ? (int) substr($range['date_end'],   0, 4) : (int) date('Y');
$years     = range($year_from, $year_to);
$hidden_history_charts = (array) get_option( 'naws_history_hidden_charts', [] );
?>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,600;0,700;0,800;1,700;1,800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<div id="<?php echo esc_attr($widget_id); ?>" class="naws-hist"
     data-nonce="<?php echo esc_attr($nonce); ?>"
     data-ajax="<?php echo esc_attr($ajax_url); ?>"
     data-outdoor="<?php echo esc_attr($outdoor_id); ?>"
     data-indoor="<?php echo esc_attr($indoor_id); ?>"
     data-years="<?php echo esc_attr(implode(',', $years)); ?>">

  <div class="naws-hist-hdr">
    <div class="naws-hist-title"><?php echo esc_html($atts['title'] ?? 'Historische Wetterdaten'); ?></div>
    <div class="naws-hist-range"><?php echo esc_html($year_from . ' – ' . $year_to); ?></div>
  </div>

  <div class="naws-hist-body">
    <?php if ( count( $hidden_history_charts ) < 4 ) : ?>
    <div class="naws-hist-loading"><div class="naws-hist-spin"></div></div>
    <?php else : ?>
    <div class="naws-hist-all-hidden">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
      <?php naws_e( 'hc_all_hidden' ); ?>
    </div>
    <?php endif; ?>

    <div id="<?php echo esc_attr($widget_id); ?>-charts" style="display:none">

      <?php if ( ! in_array( 'temp_minmax', $hidden_history_charts, true ) ) : ?>
      <!-- Temperatur Min/Max -->
      <div class="naws-hc-wrap" data-chart="temp_minmax">
        <div class="naws-hc-bar">
          <div class="naws-hc-title"><?php naws_e( 'hc_temp_minmax' ); ?></div>
          <div class="naws-hc-legend" id="<?php echo esc_attr($widget_id); ?>-leg-temp_minmax"></div>
          <button class="naws-hc-expand" data-target="temp_minmax" title="<?php echo esc_attr( naws__( 'expand_chart' ) ); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
          </button>
        </div>
        <canvas id="<?php echo esc_attr($widget_id); ?>-temp_minmax" height="90"></canvas>
      </div>
      <?php endif; ?>

      <?php if ( ! in_array( 'temp_avg', $hidden_history_charts, true ) ) : ?>
      <!-- Durchschnittstemperatur -->
      <div class="naws-hc-wrap" data-chart="temp_avg">
        <div class="naws-hc-bar">
          <div class="naws-hc-title"><?php naws_e( 'hc_temp_avg' ); ?></div>
          <div class="naws-hc-legend" id="<?php echo esc_attr($widget_id); ?>-leg-temp_avg"></div>
          <button class="naws-hc-expand" data-target="temp_avg" title="<?php echo esc_attr( naws__( 'expand_chart' ) ); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
          </button>
        </div>
        <canvas id="<?php echo esc_attr($widget_id); ?>-temp_avg" height="90"></canvas>
      </div>
      <?php endif; ?>

      <?php if ( ! in_array( 'pressure', $hidden_history_charts, true ) ) : ?>
      <!-- Luftdruck -->
      <div class="naws-hc-wrap" data-chart="pressure">
        <div class="naws-hc-bar">
          <div class="naws-hc-title"><?php naws_e( 'hc_pressure' ); ?></div>
          <div class="naws-hc-legend" id="<?php echo esc_attr($widget_id); ?>-leg-pressure"></div>
          <button class="naws-hc-expand" data-target="pressure" title="<?php echo esc_attr( naws__( 'expand_chart' ) ); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
          </button>
        </div>
        <canvas id="<?php echo esc_attr($widget_id); ?>-pressure" height="90"></canvas>
      </div>
      <?php endif; ?>

      <?php if ( ! in_array( 'rain', $hidden_history_charts, true ) ) : ?>
      <!-- Jahresregen -->
      <div class="naws-hc-wrap" data-chart="rain">
        <div class="naws-hc-bar">
          <div class="naws-hc-title"><?php naws_e( 'hc_rain' ); ?></div>
          <div class="naws-hc-legend" id="<?php echo esc_attr($widget_id); ?>-leg-rain"></div>
          <button class="naws-hc-expand" data-target="rain" title="<?php echo esc_attr( naws__( 'expand_chart' ) ); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
          </button>
        </div>
        <canvas id="<?php echo esc_attr($widget_id); ?>-rain" height="90"></canvas>
      </div>
      <?php endif; ?>

    </div>
  </div>
</div>

<!-- Modal -->
<div id="<?php echo esc_attr($widget_id); ?>-modal" class="naws-hist-modal" style="display:none">
  <div class="naws-hist-modal-bg"></div>
  <div class="naws-hist-modal-box">
    <div class="naws-hist-modal-hdr">
      <span class="naws-hist-modal-title"></span>
      <div class="naws-hist-modal-leg"></div>
      <button class="naws-hist-modal-close">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="naws-hist-modal-body">
      <canvas id="<?php echo esc_attr($widget_id); ?>-modal-canvas"></canvas>
    </div>
  </div>
</div>

<style>
#<?php echo $widget_id; ?>,
#<?php echo $widget_id; ?>-modal {
  --ink:#427272; --ink2:#2d5252; --ink3:#1a3535;
  --muted:#7aa0a0; --light:#a0b8b8;
  --line:#e0eeee; --bg:#ffffff; --card:#f4fafa; --sh:rgba(40,72,72,.08);
  font-family:'Nunito',sans-serif; color:var(--ink);
}
/* HEADER */
.naws-hist-hdr {
  background:var(--ink2); border-radius:16px 16px 0 0;
  padding:15px 24px; display:flex; justify-content:space-between; align-items:center;
}
.naws-hist-title { font-size:18px; font-weight:800; font-style:italic; color:#fff; }
.naws-hist-range { font-size:12px; font-weight:600; color:rgba(255,255,255,.6); }

/* BODY */
.naws-hist-body {
  background:var(--bg); border:1.5px solid var(--line);
  border-top:none; border-radius:0 0 16px 16px; padding:20px;
}
/* LOADER */
.naws-hist-loading { display:flex; justify-content:center; padding:60px; }
.naws-hist-all-hidden{
  display:flex;align-items:center;gap:.6rem;justify-content:center;
  padding:48px 20px;color:#6b7280;font-size:.85rem;
}
.naws-hist-spin {
  width:32px; height:32px; border-radius:50%;
  border:2px solid var(--line); border-top-color:var(--ink);
  animation:nhspin .75s linear infinite;
}
@keyframes nhspin{to{transform:rotate(360deg)}}

/* CHART WRAPPER */
.naws-hc-wrap {
  background:#ffffff; border:1.5px solid var(--line); border-radius:14px;
  padding:16px 18px 14px; margin-bottom:16px;
  box-shadow:0 2px 10px var(--sh);
  transition:transform .2s ease;
  cursor:pointer;
}
.naws-hc-wrap:hover { transform:translateY(-3px); }
.naws-hc-wrap:last-child { margin-bottom:0; }

/* CHART TOP BAR */
.naws-hc-bar {
  display:flex; align-items:center; gap:12px;
  margin-bottom:12px; flex-wrap:wrap;
}
.naws-hc-title {
  font-size:10px; font-weight:700; text-transform:uppercase;
  letter-spacing:.1em; color:var(--muted); flex-shrink:0;
}
.naws-hc-legend {
  display:flex; flex-wrap:wrap; gap:6px; flex:1;
}
.naws-hc-expand {
  background:none; border:1px solid var(--line); border-radius:6px;
  padding:4px 7px; cursor:pointer; color:var(--muted); flex-shrink:0;
  display:flex; align-items:center; transition:background .15s,color .15s;
  margin-left:auto;
}
.naws-hc-expand:hover { background:var(--ink2); color:#fff; border-color:var(--ink2); }

/* LEGEND PILLS */
.naws-leg-rain-total {
  display: inline-block;
  margin-left: 5px;
  font-size: 10px;
  font-weight: 700;
  opacity: .75;
  letter-spacing: .03em;
}
.naws-leg-pill {
  display:inline-flex; align-items:center; gap:5px;
  padding:3px 10px 3px 7px; border-radius:20px; cursor:pointer;
  border:1.5px solid transparent; font-size:10px; font-weight:700;
  transition:opacity .2s, border-color .2s;
  user-select:none;
}
.naws-leg-pill.hidden { opacity:.35; }
.naws-leg-pill-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }

/* MODAL */
.naws-hist-modal {
  position:fixed; inset:0; z-index:99999;
  display:flex; align-items:center; justify-content:center;
}
.naws-hist-modal-bg {
  position:absolute; inset:0;
  background:rgba(10,26,26,.65); backdrop-filter:blur(3px); cursor:pointer;
}
.naws-hist-modal-box {
  position:relative; z-index:1;
  background:#fff; border-radius:18px;
  width:min(96vw,1920px); max-height:92vh;
  box-shadow:0 24px 80px rgba(10,26,26,.3);
  display:flex; flex-direction:column;
  animation:nhmodal-in .22s ease;
}
@keyframes nhmodal-in{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
.naws-hist-modal-hdr {
  display:flex; align-items:center; gap:12px; flex-wrap:wrap;
  padding:16px 22px 12px; border-bottom:1px solid var(--line,#e0eeee);
}
.naws-hist-modal-title {
  font-size:12px; font-weight:700; text-transform:uppercase;
  letter-spacing:.09em; color:#7aa0a0; flex-shrink:0;
}
.naws-hist-modal-leg { display:flex; flex-wrap:wrap; gap:6px; flex:1; }
.naws-hist-modal-close {
  background:none; border:1px solid #e0eeee; border-radius:8px;
  padding:5px 8px; cursor:pointer; color:#7aa0a0;
  display:flex; align-items:center; transition:background .15s,color .15s;
  margin-left:auto;
}
.naws-hist-modal-close:hover { background:#2d5252; color:#fff; border-color:#2d5252; }
.naws-hist-modal-body { padding:16px 22px 22px; flex:1; overflow:hidden; min-height:0; }
.naws-hist-modal-body canvas { width:100%!important; height:420px!important; }
</style>

<script>
(function(){
var WID     = <?php echo json_encode($widget_id); ?>;
var AJAX    = <?php echo json_encode($ajax_url); ?>;
var NONCE   = document.getElementById(WID).dataset.nonce;
var OUTDOOR = document.getElementById(WID).dataset.outdoor;
var INDOOR  = document.getElementById(WID).dataset.indoor;
var YEARS   = document.getElementById(WID).dataset.years.split(',').map(Number).filter(Boolean);

var chartsEl = document.getElementById(WID+'-charts');
var loadEl   = document.querySelector('#'+WID+' .naws-hist-loading');

// Store per-chart: { config, yearDatasets:{year:{labels,data}}, hiddenYears:Set, chartObj }
var CHARTS = {};
var modalChart = null;

/* ── COLOURS ─────────────────────────────── */
// One colour per year, consistent palette
var PALETTE = [
  '#3d9e74','#3585b0','#7055c0','#c0392b','#e67e22',
  '#16a085','#8e44ad','#2980b9','#27ae60','#d35400',
  '#1abc9c','#e74c3c','#f39c12','#6c5ce7','#00b894',
];
function yearColor(yr){ return PALETTE[(yr - YEARS[0]) % PALETTE.length]; }

/* ── AJAX ────────────────────────────────── */
function post(params, cb){
  var xhr=new XMLHttpRequest();
  xhr.open('POST',AJAX);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload=function(){try{cb(JSON.parse(xhr.responseText));}catch(e){cb(null);}};
  var body='nonce='+encodeURIComponent(NONCE);
  Object.keys(params).forEach(function(k){
    var v=params[k];
    if(Array.isArray(v)) v.forEach(function(vi){body+='&'+encodeURIComponent(k)+'[]='+encodeURIComponent(vi);});
    else body+='&'+encodeURIComponent(k)+'='+encodeURIComponent(v);
  });
  xhr.send(body);
}

/* ── MONTH LABELS ───────────────────────── */
var MONTHS = <?php echo wp_json_encode( [
    naws__('month_jan'), naws__('month_feb'), naws__('month_mar'), naws__('month_apr'),
    naws__('month_may'), naws__('month_jun'), naws__('month_jul'), naws__('month_aug'),
    naws__('month_sep'), naws__('month_oct'), naws__('month_nov'), naws__('month_dec'),
] ); ?>;
function monthLabel(iso){ return MONTHS[parseInt(iso.slice(5,7),10)-1]; }

/* ── CHART.JS BASE OPTIONS ──────────────── */
/* Fixed Jan-Dec x-axis labels */
var MONTH_LABELS = MONTHS.slice();
var MONTH_TICKS  = ['01-01','02-01','03-01','04-01','05-01','06-01',
                    '07-01','08-01','09-01','10-01','11-01','12-01'];

/* Aggregate daily {x:'MM-DD',y:val} data to 12 monthly sums */
function aggregateMonthly(dailyData){
  var sums = [0,0,0,0,0,0,0,0,0,0,0,0];
  for(var i=0;i<dailyData.length;i++){
    var pt = dailyData[i];
    var mi = parseInt(pt.x.slice(0,2),10)-1;
    if(mi>=0 && mi<12 && pt.y!==null && !isNaN(pt.y)) sums[mi]+=parseFloat(pt.y);
  }
  var out=[];
  for(var m=0;m<12;m++) out.push({x:MONTH_LABELS[m], y:Math.round(sums[m]*100)/100});
  return out;
}

function baseOpts(unit, type, isModal, isMonthly){
  var xConfig;
  if(isMonthly){
    xConfig = {
      type:'category',
      labels: MONTH_LABELS,
      grid:{color:'rgba(218,240,240,.4)'},
      ticks:{
        color:'#7aa0a0', font:{family:'Nunito',size:10},
        maxRotation:0, autoSkip:false
      }
    };
  } else {
    xConfig = {
      type:'category',
      labels: (function(){
        var arr=[];
        var days=[31,28,31,30,31,30,31,31,30,31,30,31];
        for(var m=0;m<12;m++){
          for(var d=1;d<=days[m];d++){
            arr.push((m+1<10?'0':'')+(m+1)+'-'+(d<10?'0':'')+d);
          }
        }
        return arr;
      })(),
      grid:{color:'rgba(218,240,240,.4)'},
      ticks:{
        color:'#7aa0a0', font:{family:'Nunito',size:10},
        maxRotation:0, autoSkip:false,
        callback:function(val,idx){
          var lbl = this.getLabelForValue(idx);
          return lbl && lbl.slice(3)==='01' ? MONTH_LABELS[parseInt(lbl.slice(0,2),10)-1] : '';
        }
      }
    };
  }
  return {
    responsive:true, maintainAspectRatio:!isModal,
    animation:{duration:600,easing:'easeInOutQuart'},
    plugins:{
      legend:{display:false},
      tooltip:{
        backgroundColor:'rgba(45,82,82,.92)',
        titleColor:'#a0c8c8', bodyColor:'#fff',
        titleFont:{family:'Nunito',size:11},
        bodyFont:{family:'Nunito',size:12,weight:'bold'},
        padding:10, cornerRadius:8, displayColors:true, boxWidth:10, boxHeight:10,
        callbacks:{
          title:function(items){
            var x = items[0] ? items[0].label : '';
            if(isMonthly) return x;
            var parts = x.split('-');
            if(parts.length===2){
              var mo = parseInt(parts[0],10)-1;
              return MONTH_LABELS[mo]+' '+parseInt(parts[1],10)+'.';
            }
            return x;
          },
          label:function(c){return ' '+c.dataset.label+': '+c.parsed.y+' '+unit;}
        }
      }
    },
    scales:{
      x: xConfig,
      y:{
        grid:{color:'rgba(218,240,240,.5)'},
        ticks:{
          color:'#7aa0a0',font:{family:'Nunito',size:10},
          callback:function(v){return v;}
        },
        title:{display:true,text:unit,color:'#a0b8b8',font:{family:'Nunito',size:10,weight:'600'}}
      }
    }
  };
}

/* ── BUILD DATASET FOR ONE YEAR ─────────── */
function buildDataset(chartId, year, data, type){
  var c = yearColor(year);
  var r=parseInt(c.slice(1,3),16),g=parseInt(c.slice(3,5),16),b=parseInt(c.slice(5,7),16);
  var bg = type==='bar' ? 'rgba('+r+','+g+','+b+',.45)' : 'rgba('+r+','+g+','+b+',.12)';
  return {
    label: String(year),
    data: data,           // array of {x:'MM-DD', y:val}
    borderColor: c,
    backgroundColor: bg,
    borderWidth: type==='bar' ? 1.5 : 2,
    pointRadius: 0, pointHoverRadius: 4,
    tension: 0.35,
    fill: false,
    borderRadius: type==='bar' ? 4 : 0,
    barPercentage: 0.9,
    categoryPercentage: 0.8,
    hidden: CHARTS[chartId] ? CHARTS[chartId].hiddenYears.has(year) : false,
    parsing: { xAxisKey:'x', yAxisKey:'y' },
  };
}

/* ── RENDER CHART ───────────────────────── */
function renderChart(chartId, isModal){
  var cfg = CHARTS[chartId]; if(!cfg) return;
  var canvasId = isModal ? WID+'-modal-canvas' : WID+'-'+chartId;
  var ctx = document.getElementById(canvasId); if(!ctx) return;

  if(isModal && modalChart){ modalChart.destroy(); modalChart=null; }
  if(!isModal && cfg.chartObj){ cfg.chartObj.destroy(); cfg.chartObj=null; }

  var isMonthly = cfg.type === 'bar';
  var opts = baseOpts(cfg.unit, cfg.type, isModal, isMonthly);
  var datasets = [];

  YEARS.forEach(function(yr){
    var yd = cfg.yearData[yr]; if(!yd) return;
    datasets.push(buildDataset(chartId, yr, yd.values, cfg.type));
  });

  // For minmax: rebuild datasets with min=dashed, max=solid
  if(chartId==='temp_minmax'){
    datasets = [];
    YEARS.forEach(function(yr){
      var yd = cfg.yearData[yr]; if(!yd) return;
      var c = yearColor(yr);
      var ri=parseInt(c.slice(1,3),16),gi=parseInt(c.slice(3,5),16),bi=parseInt(c.slice(5,7),16);
      datasets.push({
        label: yr+' '+<?php echo wp_json_encode( naws__('lbl_min') ); ?>, data: yd.values_min||[],
        borderColor:'rgba('+ri+','+gi+','+bi+',.55)',
        backgroundColor:'rgba('+ri+','+gi+','+bi+',.06)',
        borderWidth:1.5, borderDash:[4,3],
        pointRadius:0, pointHoverRadius:3, tension:0.35, fill:false,
        parsing:{xAxisKey:'x',yAxisKey:'y'},
        hidden: cfg.hiddenYears.has(yr),
      });
      datasets.push({
        label: yr+' '+<?php echo wp_json_encode( naws__('lbl_max') ); ?>, data: yd.values_max||[],
        borderColor:c, backgroundColor:'rgba('+ri+','+gi+','+bi+',.12)',
        borderWidth:2, pointRadius:0, pointHoverRadius:4, tension:0.35, fill:false,
        parsing:{xAxisKey:'x',yAxisKey:'y'},
        hidden: cfg.hiddenYears.has(yr),
      });
    });
  }

  var chartObj = new Chart(ctx, {
    type: cfg.type==='bar' ? 'bar' : 'line',
    data:{ datasets:datasets },
    options: opts,
  });

  if(isModal) modalChart = chartObj;
  else cfg.chartObj = chartObj;
}

/* ── BUILD LEGEND ───────────────────────── */
function buildLegend(chartId, containerId){
  var cfg = CHARTS[chartId]; if(!cfg) return;
  var el = document.getElementById(containerId); if(!el) return;
  el.innerHTML = '';

  YEARS.forEach(function(yr){
    if(!cfg.yearData[yr]) return; // no data for this year
    var c = yearColor(yr);
    var pill = document.createElement('span');
    pill.className = 'naws-leg-pill' + (cfg.hiddenYears.has(yr)?' hidden':'');
    pill.dataset.year = yr;
    pill.dataset.chart = chartId;
    pill.style.borderColor = c;
    pill.style.background = cfg.hiddenYears.has(yr) ? 'transparent' : c+'18';

    // For rain chart: show yearly total in the pill
    var extra = '';
    if(chartId === 'rain'){
      try{
        var vals = cfg.yearData[yr] && cfg.yearData[yr].values;
        if(vals && vals.length){
          var total = 0;
          for(var i=0;i<vals.length;i++){
            var v = vals[i];
            var n = (v && typeof v==='object') ? v.y : v;
            if(n !== null && n !== undefined && !isNaN(n)) total += parseFloat(n);
          }
          extra = '<span class="naws-leg-rain-total">'+Math.round(total)+' '+cfg.unit+'</span>';
        }
      }catch(e){}
    }

    pill.innerHTML = '<span class="naws-leg-pill-dot" style="background:'+c+'"></span>'+yr+extra;
    pill.addEventListener('click', function(e){
      e.stopPropagation();
      toggleYear(chartId, yr, containerId);
    });
    el.appendChild(pill);
  });
}

function toggleYear(chartId, year, legendId){
  var cfg = CHARTS[chartId]; if(!cfg) return;
  if(cfg.hiddenYears.has(year)) cfg.hiddenYears.delete(year);
  else cfg.hiddenYears.add(year);

  // Update chart datasets visibility
  if(cfg.chartObj){
    cfg.chartObj.data.datasets.forEach(function(ds){
      var dsYear = parseInt(ds.label);
      if(dsYear===year) ds.hidden = cfg.hiddenYears.has(year);
      // minmax: label is "2023 Min" / "2023 Max"
      if(ds.label.startsWith(year+' ')) ds.hidden = cfg.hiddenYears.has(year);
    });
    cfg.chartObj.update();
  }
  // Also update modal if open for same chart
  if(modalChart && currentModalChart===chartId){
    modalChart.data.datasets.forEach(function(ds){
      var dsYear = parseInt(ds.label);
      if(dsYear===year) ds.hidden = cfg.hiddenYears.has(year);
      if(ds.label.startsWith(year+' ')) ds.hidden = cfg.hiddenYears.has(year);
    });
    modalChart.update();
    // Sync modal legend
    buildLegend(chartId, WID+'-modal-leg-'+chartId);
  }

  buildLegend(chartId, legendId);
  buildLegend(chartId, WID+'-modal-leg-'+chartId);
}

/* ── MODAL ───────────────────────────────── */
var modal = document.getElementById(WID+'-modal');
var currentModalChart = null;

function openModal(chartId){
  if(!modal||!CHARTS[chartId]) return;
  currentModalChart = chartId;
  var cfg = CHARTS[chartId];

  modal.querySelector('.naws-hist-modal-title').textContent = cfg.title;

  // Build modal legend
  var mleg = modal.querySelector('.naws-hist-modal-leg');
  var legId = WID+'-modal-leg-'+chartId;
  mleg.id = legId;
  mleg.innerHTML = '';
  buildLegend(chartId, legId);

  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';

  setTimeout(function(){ renderChart(chartId, true); }, 30);
}
function closeModal(){
  if(!modal) return;
  modal.style.display = 'none';
  document.body.style.overflow = '';
  if(modalChart){ modalChart.destroy(); modalChart=null; }
  currentModalChart = null;
}

modal.querySelector('.naws-hist-modal-bg').addEventListener('click', closeModal);
modal.querySelector('.naws-hist-modal-close').addEventListener('click', closeModal);
document.addEventListener('keydown',function(e){ if(e.key==='Escape') closeModal(); });

// Expand buttons + card click
document.addEventListener('click', function(e){
  var btn = e.target.closest('.naws-hc-expand');
  if(btn){ openModal(btn.dataset.target); return; }
  var wrap = e.target.closest('.naws-hc-wrap');
  if(wrap && !e.target.closest('.naws-leg-pill')){ openModal(wrap.dataset.chart); }
});

/* ── LOAD DATA ───────────────────────────── */
// Chart definitions
/* ── CHART DEFINITIONS ──────────────────── */
// Each chart fetches one request per year spanning Jan-Dec, group_by=month
// The daily_data endpoint returns datasets keyed by field label (e.g. "Temp Min (°C)")
// We identify fields by checking which field key was requested
// All possible chart definitions
var ALL_CHART_DEFS = <?php
$opts      = get_option( 'naws_settings', [] );
$temp_unit = ( $opts['temperature_unit'] ?? 'C' ) === 'F' ? '°F' : '°C';
$pres_unit = NAWS_Helpers::get_unit( 'Pressure' );
$rain_unit = $opts['rain_unit'] ?? 'mm';
echo wp_json_encode( [
  [ 'id'=>'temp_minmax', 'title'=>naws__( 'hc_temp_minmax' ), 'type'=>'line', 'unit'=>$temp_unit, 'fields'=>['temp_min','temp_max'],   'moduleId'=>'' ],
  [ 'id'=>'temp_avg',    'title'=>naws__( 'hc_temp_avg' ),    'type'=>'line', 'unit'=>$temp_unit, 'fields'=>['temp_avg'],              'moduleId'=>'' ],
  [ 'id'=>'pressure',    'title'=>naws__( 'hc_pressure' ),    'type'=>'line', 'unit'=>$pres_unit, 'fields'=>['pressure_avg'],          'moduleId'=>'' ],
  [ 'id'=>'rain',        'title'=>naws__( 'hc_rain' ),        'type'=>'bar',  'unit'=>$rain_unit, 'fields'=>['rain_sum'],              'moduleId'=>'' ],
] ); ?>;

// Only initialize charts whose canvas is actually in the DOM (not disabled by admin)
var CHART_DEFS = ALL_CHART_DEFS.filter(function(def){
  return !!document.getElementById(WID+'-'+def.id);
});

CHART_DEFS.forEach(function(def){
  CHARTS[def.id] = {
    title:def.title, type:def.type, unit:def.unit,
    fields:def.fields, yearData:{}, hiddenYears:new Set(), chartObj:null,
  };
});



/* One request per chart: fetch all years at once from dedicated history endpoint */
var pending = CHART_DEFS.length;
var loaded  = 0;

// If all charts are disabled by admin, skip spinner immediately
if(pending === 0){
  if(loadEl) loadEl.style.display = 'none';
}

function checkDone(){
  if(++loaded >= pending){
    loadEl.style.display = 'none';
    chartsEl.style.display = '';
    CHART_DEFS.forEach(function(def){
      renderChart(def.id, false);
      buildLegend(def.id, WID+'-leg-'+def.id);
    });
  }
}

CHART_DEFS.forEach(function(def){
  var body = 'nonce='+encodeURIComponent(NONCE)
    +'&action=naws_get_history_data'
    +'&year_from='+YEARS[0]
    +'&year_to='+YEARS[YEARS.length-1];
  def.fields.forEach(function(f){ body+='&fields[]='+encodeURIComponent(f); });

  var xhr=new XMLHttpRequest();
  xhr.open('POST',AJAX);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload=function(){
    try{
      var r=JSON.parse(xhr.responseText);
      if(r&&r.success&&r.data&&r.data.series&&r.data.series.length){
        // series = [{year, field, data:[{x:'Jan',y:val},...]}]
        r.data.series.forEach(function(s){
          var yr = s.year;
          if(!CHARTS[def.id].yearData[yr]){
            CHARTS[def.id].yearData[yr]={labels:[],values:[],values_min:[],values_max:[]};
          }
          var yd = CHARTS[def.id].yearData[yr];
          // labels: use x value; fill empty strings with previous non-empty label
          // Store as {x:'MM-DD', y:val} objects for scatter-style category mapping
          if(s.field==='temp_min')      yd.values_min = s.data;
          else if(s.field==='temp_max') yd.values_max = s.data;
          else yd.values = def.type==='bar' ? aggregateMonthly(s.data) : s.data;
        });
      } else {
        console.warn('naws history NO DATA', def.id, r&&r.data||'no data');
      }
    }catch(e){ console.warn('naws history error',e,xhr.responseText.substr(0,300)); }
    checkDone();
  };
  xhr.onerror=function(){ checkDone(); };
  xhr.send(body);
});

})();
</script>
