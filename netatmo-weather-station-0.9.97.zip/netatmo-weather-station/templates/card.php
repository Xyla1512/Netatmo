<?php
/* templates/card.php – [naws_card] single metric card */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! $row ) {
    echo '<p style="color:#64748b">--</p>';
    return;
}

$param    = $atts['parameter'];
$val      = NAWS_Helpers::format_value( $param, floatval( $row['value'] ) );
$unit     = NAWS_Helpers::get_unit( $param );
$label    = ! empty( $atts['title'] ) ? $atts['title'] : NAWS_Helpers::get_label( $param );
$icon     = NAWS_Helpers::get_icon( $param );
$css      = NAWS_Helpers::get_css_class( $param );
$animate  = $atts['animate'] !== 'false';
?>
<div class="naws-wrap naws-theme-light">
    <div class="naws-grid naws-grid-1">
        <div class="naws-card <?php echo esc_attr( $css ); ?>">
            <span class="naws-card-icon"><?php echo esc_html( $icon ); ?></span>
            <div class="naws-card-label"><?php echo esc_html( $label ); ?></div>
            <div class="naws-card-value">
                <?php if ( $animate ) : ?>
                    <span class="naws-count-up" data-value="<?php echo esc_attr( $val ); ?>">0</span>
                <?php else : ?>
                    <span><?php echo esc_html( $val ); ?></span>
                <?php endif; ?>
                <span class="naws-card-unit"><?php echo esc_html( $unit ); ?></span>
            </div>
            <div class="naws-card-meta"><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' H:i', $row['recorded_at'] ) ); ?></div>
        </div>
    </div>
</div>
