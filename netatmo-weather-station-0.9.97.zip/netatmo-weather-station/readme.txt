=== Netatmo Weather Station Pro ===
Contributors: yourname
Tags: netatmo, weather station, weather, temperature, humidity, elementor
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Reads, stores and displays all data from your Netatmo weather station with animated charts, gauges, Elementor widgets and full customization.

== Description ==

**Netatmo Weather Station Pro** is a professional plugin that connects to the Netatmo API, stores all sensor readings in your local WordPress database, and displays them beautifully on your site.

= Features =

**Data Collection**
* Full OAuth2 authentication with Netatmo API
* Reads ALL modules: Base station, Outdoor, Wind, Rain, Indoor modules
* All parameters: Temperature, Humidity, CO₂, Noise, Pressure, Wind, Rain, Health Index
* Automatic sync every X minutes via WordPress Cron (configurable: 5–1440 min)
* Manual one-click sync in backend
* Historical data import via getmeasure API (chunk-by-chunk to avoid rate limits)
* Configurable data retention (default: 365 days)

**Display / Frontend**
* `[naws_dashboard]` – Full dashboard with tabs per module, charts, overview
* `[naws_current]` – Animated metric cards grid/list
* `[naws_chart]` – Interactive Chart.js charts with range picker (24h/7d/30d/90d)
* `[naws_gauge]` – Animated gauge for single metric
* `[naws_card]` – Single metric card for sidebars
* `[naws_table]` – Historical data table (pivoted, grouped)
* Dark and light themes
* Animated number counters on scroll
* CO₂ color-coded air quality levels
* Wind compass direction indicator
* Battery level indicator for modules
* Responsive / mobile-friendly

**Elementor Integration**
* 4 Elementor widgets: Current Readings, Chart, Full Dashboard, Gauge
* Organized in "Weather Station" category
* Full visual control panel per widget

**Backend / Admin**
* Clean dashboard with live statistics
* Settings: OAuth credentials, cron interval, units, colors, theme
* All unit conversions: °C/°F, mm/inch, mbar/inHg/mmHg, km/h/m/s/mph/kn
* Modules overview with battery levels
* Cron event log (last 50 entries)
* Historical import with progress bar and stop button
* Shortcode reference guide

= Supported Module Types =
* **NAMain** – Base Station (indoor: Temperature, Humidity, CO₂, Noise, Pressure)
* **NAModule1** – Outdoor Module (Temperature, Humidity)
* **NAModule2** – Wind Module (Wind speed/angle, Gust speed/angle)
* **NAModule3** – Rain Gauge (Rain accumulation)
* **NAModule4** – Additional Indoor Module (Temperature, Humidity, CO₂)

== Installation ==

1. Upload `netatmo-weather-station` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress Admin
3. Go to **Weather Station > Settings**
4. Create a Netatmo developer app at https://dev.netatmo.com
5. Enter your Client ID and Client Secret
6. Click "Connect to Netatmo" and authorize
7. Your station data will be loaded automatically
8. Add shortcodes to any page or use Elementor widgets

== Frequently Asked Questions ==

= How do I get a Netatmo Client ID? =
Go to https://dev.netatmo.com, log in with your Netatmo account, create a new application, and copy the Client ID and Client Secret.

= What is the redirect URI to add in Netatmo app settings? =
Use your WordPress admin URL: `https://yoursite.com/wp-admin/admin.php?page=naws-settings`

= Why do I need to import historical data manually? =
Netatmo's getmeasure API returns a maximum of 1024 data points per call. For longer periods, data must be fetched in chunks. The manual import lets you control this process, import month-by-month at your own pace.

= Does the plugin work without Elementor? =
Yes! All features are available via shortcodes that work in any page builder or classic editor.

= How often does the data update? =
Netatmo sensors send data every 5 minutes. You can set the cron interval to match (minimum: 5 minutes).

== Changelog ==

= 1.0.0 =
* Initial release

== License ==
GPLv2 or later
